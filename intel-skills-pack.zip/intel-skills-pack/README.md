# Intel Skills Pack

包含两个可直接复用的 OpenClaw 技能：

1. `intel-sentiment-watch`
2. `intel-competitor-track`

## 用途
- 舆情监控（声量、情绪、负面预警）
- 竞品追踪（官网/定价/功能/广告与渠道变化）

## 迁移方式（给其他 AI）
1. 将两个技能目录放入对方工作区的 `skills/` 目录
2. 保持目录名不变
3. 让对方 AI 读取对应 `SKILL.md` 即可执行同流程

## 建议
- 若用于定时任务，请在调用消息中固定：监控对象、竞品范围、时间窗、输出格式
